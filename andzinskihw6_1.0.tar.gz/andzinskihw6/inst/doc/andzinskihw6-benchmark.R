### R code from vignette source 'andzinskihw6-benchmark.Rnw'

###################################################
### code chunk number 1: andzinskihw6-benchmark.Rnw:21-22
###################################################
library(andzinskihw6)


###################################################
### code chunk number 2: andzinskihw6-benchmark.Rnw:33-36
###################################################
mode2 <- function(x) {
  which.max(table(x))
}


###################################################
### code chunk number 3: andzinskihw6-benchmark.Rnw:41-46
###################################################
microbenchmark::microbenchmark(
  mode(c(1:100000)),
  mode2(c(1:100000)),
  times=10
)


###################################################
### code chunk number 4: andzinskihw6-benchmark.Rnw:49-54
###################################################
microbenchmark::microbenchmark(
  mode(c(1:10000)),
  mode2(c(1:10000)),
  times=100
)


###################################################
### code chunk number 5: andzinskihw6-benchmark.Rnw:57-62
###################################################
microbenchmark::microbenchmark(
  mode(c(1:10)),
  mode2(c(1:10)),
  times=100
)


###################################################
### code chunk number 6: andzinskihw6-benchmark.Rnw:71-76
###################################################
microbenchmark::microbenchmark(
  simplify2array(list(c(1:1000),c(1:1000))),
  base::simplify2array(list(c(1:1000),c(1:1000))),
  times=100
)


###################################################
### code chunk number 7: andzinskihw6-benchmark.Rnw:81-86
###################################################
microbenchmark::microbenchmark(
  simplify2array(list(c(1:100000),c(1:100000))),
  base::simplify2array(list(c(1:1000),c(1:1000))), 
  times=100
)


###################################################
### code chunk number 8: andzinskihw6-benchmark.Rnw:92-97
###################################################
microbenchmark::microbenchmark(
  simplify2array(list(c(1:10000))),
  base::simplify2array(list(c(1:10000))) ,
  times=100
)


###################################################
### code chunk number 9: andzinskihw6-benchmark.Rnw:105-108
###################################################
n <- sapply(c(1:10), function(x) { nrow(ass(x)) })
names(n) <- c(1:10)
as.matrix(n)


###################################################
### code chunk number 10: andzinskihw6-benchmark.Rnw:111-112
###################################################
plot(n, xlab="n", ylab="nrow(ass(n))")


###################################################
### code chunk number 11: andzinskihw6-benchmark.Rnw:117-120
###################################################
n <- sapply(c(1:10), function(x) { object.size(ass(x)) })
names(n) <- c(1:10)
as.matrix(n)


###################################################
### code chunk number 12: andzinskihw6-benchmark.Rnw:123-124
###################################################
plot(n, xlab="n", ylab="object.size(ass(n)) [bytes]")


