### R code from vignette source 'andzinskihw6-package.Rnw'

###################################################
### code chunk number 1: andzinskihw6-package.Rnw:20-21
###################################################
library(andzinskihw6)


###################################################
### code chunk number 2: andzinskihw6-package.Rnw:32-33
###################################################
mode(c(1,1,2))


###################################################
### code chunk number 3: andzinskihw6-package.Rnw:37-38
###################################################
mode(c(1,1,NA,NA,2,NA,NA))


###################################################
### code chunk number 4: andzinskihw6-package.Rnw:43-44
###################################################
mode(c(NA,NA,NA,NA))


###################################################
### code chunk number 5: andzinskihw6-package.Rnw:52-55
###################################################
simplify2array(list(c(1,2),c(3,4)))
simplify2array(list(c(1),c(2)))
simplify2array(list(c(1,2,3)))


###################################################
### code chunk number 6: andzinskihw6-package.Rnw:60-62
###################################################
simplify2array(list(c(1,2),c("a","b")))
base::simplify2array(list(c(1,2),c("a","b")))


###################################################
### code chunk number 7: andzinskihw6-package.Rnw:69-70
###################################################
ass(2)


