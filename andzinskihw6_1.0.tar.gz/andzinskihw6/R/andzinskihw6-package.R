#' @title andzinskihw6
#'
#' @description
#' Advanced data analysis software development with R - Homework 6
#'
#' @useDynLib andzinskihw6
#' @name andzinskihw6-package
#' @docType package
#' @importFrom Rcpp sourceCpp
invisible(NULL)